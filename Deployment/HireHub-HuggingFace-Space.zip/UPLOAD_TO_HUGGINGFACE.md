# دليل الرفع اليدوي لمشروع HireHub إلى Hugging Face Space (Manual Upload Guide)

هذا الدليل يشرح خطوة بخطوة كيفية رفع حزمة النشر المجهزة (`deployment/huggingface-space/` أو الأرشيف المضغوط) إلى **Hugging Face Docker Space واحد متكامل**.

---

## 📋 المتطلبات المسبقة (Prerequisites)

1. حساب مفعل على [Hugging Face](https://huggingface.co).
2. حزمة النشر الجاهزة الموجودة في مجلد:
   `deployment/huggingface-space/` (أو الملف المضغوط `deployment/HireHub-HuggingFace-Space.zip`).

---

## 🚀 خطوات الرفع والنشر اليدوي (Step-by-Step Instructions)

### الخطوة 1: إنشاء Space جديد على Hugging Face
1. انتقل إلى الرابط: [https://huggingface.co/new-space](https://huggingface.co/new-space).
2. حدد اسم الـ Space (مثال: `hirehub-platform`).
3. اختر نوع الـ License (مثال: `mit` أو `apache-2.0`).
4. في قسم **Space SDK**، اختر **Docker** (Blank).
5. حدد نوع المساحة: **Public** أو **Private**.
6. في قسم **Space Hardware**، اختر **CPU Basic (2 vCPU · 16 GB RAM - Free)**.
7. اضغط على زر **Create Space**.

---

### الخطوة 2: تهيئة الأسرار والمتغيرات البيئية (Secrets & Variables)
قبل أو بعد رفع الملفات، توجه إلى تبويب **Settings** داخل الـ Space الخاص بك:
1. انزل إلى قسم **Variables and secrets**.
2. أضف الـ Secrets التالية بالضغط على **New secret**:
   - **`AI_SERVICE_KEY`**: مفتاح سري عشوائي للمصادقة بين الباك إند وخدمة الذكاء الاصطناعي (مثال: سلسلة نصية عشوائية قوية).
   - **`JWT_SECRET`**: مفتاح سري عشوائي لتوليد وتوقيع جلسات المستخدمين (JSON Web Tokens).
   - *(اختياري)* **`RAVENACE_API_KEY_ID`** و **`RAVENACE_API_KEY_SECRET`**: في حال الرغبة بربط اختبارات تقييم RavenACE.
   - *(اختياري)* **`DB_URL`**: في حال الرغبة بربط قاعدة بيانات خارجية مثل MongoDB Atlas بدلاً من قاعدة البيانات الداخلية.

---

### الخطوة 3: رفع ملفات حزمة النشر إلى الـ Space

يمكنك اختيار إحدى الطريقتين التاليتين:

#### 🔹 الخيار أ: الرفع المباشر عبر واجهة المتصفح (Web UI)
1. افتح تبويب **Files** داخل الـ Space.
2. اضغط على زر **Add file** ثم اختر **Upload files**.
3. اسحب وأفلت محتويات مجلد `deployment/huggingface-space/` بالكامل:
   - `Dockerfile`
   - `README.md`
   - `.dockerignore`
   - `nginx.conf`
   - `supervisord.conf`
   - `entrypoint.sh`
   - المجلدات: `Frontend/`, `Backend/`, `ai-service/`
4. في أسفل الصفحة، اكتب رسالة الـ Commit:
   `Initial HireHub full-stack deployment`
5. اضغط على **Commit changes to main**.

#### 🔹 الخيار ب: الرفع عبر Git CLI محلياً من جهازك
```bash
# 1. استنساخ مستودع الـ Space الفارغ
git clone https://huggingface.co/spaces/<USERNAME>/<SPACE_NAME> hf-space-temp
cd hf-space-temp

# 2. نسخ محتويات مجلد deployment/huggingface-space إليه
cp -r /path/to/HireHub/deployment/huggingface-space/* .
cp -r /path/to/HireHub/deployment/huggingface-space/.* . 2>/dev/null || true

# 3. تثبيت التغييرات ورفعها
git add .
git commit -m "Deploy HireHub full-stack single-container architecture"
git push origin main
```

---

### الخطوة 4: متابعة البناء وفحص السجلات (Build & Logs Verification)

1. بمجرد إتمام الـ Commit، سيبدأ Hugging Face تلقائياً ببناء صورة الـ Docker (`Building`).
2. افتح تبويب **Logs** داخل الـ Space لمتابعة تقدم عملية البناء والتشغيل:
   - بناء React/Vite Frontend.
   - تثبيت حزم Node.js للـ Backend.
   - تثبيت PyTorch CPU وحزم الـ AI.
   - تشغيل `supervisord` وإطلاق MongoDB, Redis, AI Service, Backend, و Nginx.
3. انتظر حتى تتغير حالة الـ Space إلى **`Running`** (باللون الأخضر).

---

### الخطوة 5: التحقق من صحة النظام والتطبيق المباشر (Health Check)

1. **فحص نقطة الصحة العامة**:
   قم بزيارة الرابط في المتصفح:
   `https://<USERNAME>-<SPACE_NAME>.hf.space/health`
   يجب أن يعيد:
   ```json
   {
     "success": true,
     "service": "hirehub-backend",
     "database": "connected"
   }
   ```
2. **تجربة التطبيق بالكامل**:
   - افتح الرابط الأساسي: `https://<USERNAME>-<SPACE_NAME>.hf.space/`
   - سجل حساب جديد كـ Candidate أو Company.
   - تصفح الوظائف أو أنشئ وظيفة جديدة.
   - ارفع سيرة ذاتية واختبر مطابقة الـ AI والـ Socket.IO في الوقت الفعلي.

---

### ⚠️ ملاحظات هامة حول التخزين والموارد (Storage & Persistence Notes)

- **بيئة مجانية (Free Tier)**: الحاوية تعمل بذاكرة 16GB RAM ومعالجين (2 vCPU) وهو ما يغطي متطلبات التشغيل بالكامل مع فائض كبير (>14GB).
- **استمرارية البيانات**: في الخطة المجانية، يتم إعادة تهيئة التخزين المحلي في حال إعادة بناء الـ Space بالكامل. لضمان استمرارية دائمة للبيانات والملفات المرفوعة للإنتاج التجاري، يُنصح بتفعيل **Persistent Storage** من إعدادات الـ Space أو ربط قاعدة بيانات سحابية (MongoDB Atlas) عبر إضافة متغير `DB_URL` في الـ Secrets.
