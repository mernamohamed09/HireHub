---
title: HireHub Full-Stack Platform
emoji: 🚀
colorFrom: blue
colorTo: indigo
sdk: docker
app_port: 7860
pinned: false
license: mit
short_description: Complete AI-Powered Recruitment Platform (Frontend + Backend + AI ATS + DB)
---

# HireHub — Single Hugging Face Space Full-Stack Deployment

[![Hugging Face Space](https://img.shields.io/badge/%F0%9F%A4%97%20Hugging%20Face-Spaces-blue)](https://huggingface.co/spaces)
[![Docker](https://img.shields.io/badge/Docker-Multi--Stage-2496ED.svg?logo=docker)](https://www.docker.com)
[![React](https://img.shields.io/badge/React-19-61DAFB.svg?logo=react)](https://react.dev)
[![Node.js](https://img.shields.io/badge/Node.js-20-339933.svg?logo=nodedotjs)](https://nodejs.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.115-009688.svg?logo=fastapi)](https://fastapi.tiangolo.com)
[![MongoDB](https://img.shields.io/badge/MongoDB-7.0-47A248.svg?logo=mongodb)](https://www.mongodb.com)
[![Redis](https://img.shields.io/badge/Redis-7.2-DC382D.svg?logo=redis)](https://redis.io)

This package contains the **complete, unified HireHub platform** engineered to run inside **ONE SINGLE Hugging Face Docker Space**.

---

## 🏛️ Architecture Overview

All services run inside a single supervised container fronted by an Nginx Reverse Proxy listening on port `7860`:

```text
                               PUBLIC USER
                                    │
                                    ▼
                         Hugging Face Space URL
                                    │
                                Port 7860
                                    │
                                    ▼
                                  NGINX
                                    │
                  ┌─────────────────┼─────────────────┐
                  ▼                 ▼                 ▼
               Frontend          Backend          Socket.IO
             (React 19 SPA)  (Node.js/Express)  (WebSockets)
                                    │
                    ┌───────────────┼───────────────┐
                    ▼               ▼               ▼
                 MongoDB          Redis         AI ATS Engine
                (Port 27017)   (Port 6379)     (FastAPI/PyTorch)
                                                      │
                                                      ▼
                                                  ML Models
```

---

## 🔒 Security & Internal Port Isolation

All database and microservice ports are strictly bound to `127.0.0.1` and are **never exposed to the public internet**:

| Service | Internal Address | Public Exposure | Protection Mechanism |
| :--- | :---: | :---: | :--- |
| **Nginx Reverse Proxy** | `0.0.0.0:7860` | **PUBLIC** | Single Entrypoint (`/`, `/api/`, `/socket.io/`) |
| **Express Backend** | `127.0.0.1:5000` | **INTERNAL ONLY** | Proxied via Nginx `/api/` with JWT auth |
| **FastAPI AI ATS Engine** | `127.0.0.1:8008` | **INTERNAL ONLY** | Fail-Closed `X-AI-Service-Key` header |
| **MongoDB** | `127.0.0.1:27017` | **INTERNAL ONLY** | Loopback binding only |
| **Redis** | `127.0.0.1:6379` | **INTERNAL ONLY** | Loopback binding only |

---

## ⚙️ Environment Variables & Space Secrets

When creating the Hugging Face Space, configure the following secrets under **Settings -> Variables and secrets**:

| Secret Name | Required | Default / Description |
| :--- | :---: | :--- |
| `AI_SERVICE_KEY` | **Yes** | Shared key between Express backend and FastAPI AI service |
| `JWT_SECRET` | **Yes** | Secure random 64-character string for user session tokens |
| `RAVENACE_API_KEY_ID` | Optional | API Key ID for RavenACE assessment SaaS integration |
| `RAVENACE_API_KEY_SECRET` | Optional | API Secret for RavenACE assessment SaaS integration |
| `DB_URL` | Optional | `mongodb://127.0.0.1:27017/hirehub` (defaults to internal DB) |
| `REDIS_URL` | Optional | `redis://127.0.0.1:6379` (defaults to internal Redis) |

---

## 📖 Manual Upload Guide

For step-by-step instructions on uploading this package manually to Hugging Face, see:
[`UPLOAD_TO_HUGGINGFACE.md`](UPLOAD_TO_HUGGINGFACE.md).
