#!/usr/bin/env bash
# ==============================================================================
# HireHub Full-Stack Single-Container Entrypoint
# ==============================================================================
set -e

echo "==> [HireHub] Initializing Full-Stack Environment..."

# Ensure required directories exist
mkdir -p /data/db /data/redis /var/log/supervisor /var/run
mkdir -p /app/Backend/uploads/cvs /app/Backend/uploads/avatars
mkdir -p /app/.cache/huggingface

# Set sensible defaults for environment variables if omitted
export PORT="${PORT:-7860}"
export NODE_ENV="${NODE_ENV:-production}"
export DB_URL="${DB_URL:-mongodb://127.0.0.1:27017/hirehub}"
export REDIS_URL="${REDIS_URL:-redis://127.0.0.1:6379}"
export AI_SERVICE_URL="${AI_SERVICE_URL:-http://127.0.0.1:8008}"
export AI_SERVICE_KEY="${AI_SERVICE_KEY:-dfghjuikop[kjhbgvc]}"
export JWT_SECRET="${JWT_SECRET:-hirehub-hf-space-secure-jwt-key-2026}"

echo "==> [HireHub] Configuration:"
echo "    - Public Space Port: ${PORT}"
echo "    - Environment:       ${NODE_ENV}"
echo "    - Internal Database: ${DB_URL}"
echo "    - Internal Redis:    ${REDIS_URL}"
echo "    - Internal AI ATS:   ${AI_SERVICE_URL}"

# Substitute public port in Nginx configuration if dynamic
if [ "${PORT}" != "7860" ]; then
    sed -i "s/listen 7860;/listen ${PORT};/g" /etc/nginx/nginx.conf
fi

echo "==> [HireHub] Starting Process Supervisor (MongoDB, Redis, AI ATS, Backend, Nginx)..."
exec /usr/bin/supervisord -c /etc/supervisor/conf.d/supervisord.conf
